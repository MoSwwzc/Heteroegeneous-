import copy
import torch
import numpy as np
from pathlib import Path
from easydict import EasyDict as edict
import logging
import itertools
import argparse
import time

import models
from models import predictors as P
from models import losses as L
from dti_graph_test import construct_graph
from utils import data_loader, dti_graph, sampler, config_loader, my_record, training_utils, base
import pandas as pd



# def predict_lncRNAs_for_drugs(args,drug_id):
#     DATA_DIR = Path("./datasets")
#
#     # load the trained model
#     model = torch.load('model/model_en.pth')
#     model.eval()
#
#     #prepare data
#     data = data_loader.preparation(n_features=args.n_features,dataset_dir=DATA_DIR/args.dataset,
#                                    top_thr=args.top_thr,not_rand_feat=args.not_rand_feat,pca=args.pca,device=args.device)
#     # get drug feature and all lncRNA features
#
#     ld_adj = data.ld_adj.cpu().numpy()
#     ld_adj = ld_adj.T
#
#     # find lncRNAs that are not associated with the given drug
#     indices_0 = np.where(ld_adj[:,drug_id]==0)[0]
#     indices_1 = np.where(ld_adj[:,drug_id]==1)[0]
#
#     num_0 = len(indices_0)
#     # Construct features for non-associated lncRNAs
#
#     test_index = torch.randperm(num_0)
#
#     # Create a modified ld_adj for prediction
#     pred_ld_adj = torch.zeros_like(data.ld_adj).to(args.device)
#     # pred_ld_adj[indices_1, drug_id] = 1
#     pred_ld_adj[:, drug_id][indices_1] = 1
#     print(pred_ld_adj.shape)
#
#
#     # Use the same graph construction method as in training
#     pred_graph = construct_graph(
#         dd_adj=data.dd_adj,
#         ll_adj=data.ll_adj,
#         ld_adj=data.ld_adj,
#         test_edge_index= test_index,  # Using test_edge_index for prediction
#         device=args.device,
#         drug_id=drug_id
#     )
#
#
#
#     with torch.no_grad():
#         output = model(pred_graph, data.node_features)
#         drug_features = output['drug'][drug_id]
#         lncrna_features = output['lncRNA'][indices_0]
#         # 计算关联分数
#         logits = drug_features @ lncrna_features.T
#
#
#         probabilities = torch.sigmoid(logits).cpu().numpy()
#
#     # ============ Sort and output the results ============
#     sorted_indices = probabilities.argsort()[::-1] # Sort in descending order
#     sorted_lncrna_ids = indices_0[sorted_indices]  # Map back to original lncRNA indices
#     sorted_probabilities = probabilities[sorted_indices]
#
#     df1 = pd.read_csv('datasets/Gold/e/adj/5.0%/ld.csv', header=0)
#     lncRNA_name = df1.iloc[:, 0].tolist()
#     sorted_lncRNA_name = [lncRNA_name[idx] for idx in sorted_lncrna_ids.astype(int)]
#
#     results = [(lncrna_name, prob) for lncrna_name, prob in zip(sorted_lncRNA_name, sorted_probabilities)]
#     # print(results)
#     return results

def predict_drugs_for_lncRNA(args, lncRNA_id):
    DATA_DIR = Path("./datasets")

    # load model
    model = torch.load('model/model_en.pth')
    model.eval()

    # prepare data
    data = data_loader.preparation(
        n_features=args.n_features,
        dataset_dir=DATA_DIR / args.dataset,
        top_thr=args.top_thr,
        not_rand_feat=args.not_rand_feat,
        pca=args.pca,
        device=args.device
    )

    ld_adj = data.ld_adj.cpu().numpy()  # shape: [n_lncRNAs, n_drugs]

    # 找到该 lncRNA 没有关联的药物索引（列）
    indices_0 = np.where(ld_adj[lncRNA_id, :] == 0)[0]
    indices_1 = np.where(ld_adj[lncRNA_id, :] == 1)[0]

    test_index = torch.randperm(len(indices_0))

    # 构建预测 ld_adj（只保留已知的正样本）
    pred_ld_adj = torch.zeros_like(data.ld_adj).to(args.device)
    pred_ld_adj[lncRNA_id, indices_1] = 1

    # 构图（注意此时 drug_id 实际是 lncRNA_id）
    pred_graph = construct_graph(
        dd_adj=data.dd_adj,
        ll_adj=data.ll_adj,
        ld_adj=data.ld_adj,
        test_edge_index=test_index,
        device=args.device,
        drug_id=lncRNA_id  # 名称为 drug_id 但你传的是 lncRNA
    )

    with torch.no_grad():
        output = model(pred_graph, data.node_features)

        lncrna_feature = output['lncRNA'][lncRNA_id]         # shape: [dim]
        drug_features = output['drug'][indices_0]            # shape: [num_drugs, dim]
        logits = lncrna_feature @ drug_features.T            # shape: [num_drugs]
        probabilities = torch.sigmoid(logits).cpu().numpy()  # shape: [num_drugs]

    # 排序
    sorted_indices = probabilities.argsort()[::-1]
    sorted_drug_ids = indices_0[sorted_indices]
    sorted_probabilities = probabilities[sorted_indices]

    # 药物名称
    df2 = pd.read_csv('datasets/Gold/e/adj/5.0%/ld.csv', header=0)
    drug_names = df2.columns.tolist()
    sorted_drug_names = [drug_names[i] for i in sorted_drug_ids]

    results = list(zip(sorted_drug_names, sorted_probabilities))
    return results

def parse_arguments():
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    DATA_DIR = Path("./datasets")
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', type=str, default="EN", help="task name")
    parser.add_argument('--output_dir', type=str, default="results", help="output directory")

    parser.add_argument('--config', type=str, default="configs/Mode-P/SAGE.yaml", help="config to use")
    parser.add_argument('--dataset', type=str, default="Gold/e", help="dataset to use")
    parser.add_argument('--epochs', type=int, default=1000, help='number of epochs to train')
    parser.add_argument('--top_thr', type=float, default=0.05, help='top threshold of similarity matrix')

    parser.add_argument('--n_features', type=int, default=32, help='number of features to use')
    parser.add_argument('--hidden_dim', type=int, default=-1, help='hidden dimension of the model, -1: use config file')
    parser.add_argument('--sim2feat', dest='not_rand_feat', action='store_true', default=False)
    parser.add_argument('--pca', dest='pca', action='store_true', default=False)
    parser.add_argument('--device', type=str,
                        default=DEVICE, help='device to use')
    args = parser.parse_args()
    return args

import random
if torch.cuda.is_available():

    torch.cuda.manual_seed_all(2341)
seed=2341
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)
args = parse_arguments()


lncRNA_id = 30
# predictions= predict_lncRNAs_for_drugs(args,drug_id)
predictions= predict_drugs_for_lncRNA(args,lncRNA_id)
top_10_predictions = predictions[:60]
top_10_lncRNA_names_and_scores = [(lncRNA_name, score) for lncRNA_name, score in top_10_predictions]
print(top_10_lncRNA_names_and_scores)
df2 = pd.read_csv('datasets/Gold/e/adj/5.0%/ld.csv', header=0)
drug_name = df2.iloc[:,0].tolist()
print(drug_name)
drug_name = drug_name[lncRNA_id]
print(drug_name)
top_10_df = pd.DataFrame(top_10_lncRNA_names_and_scores,columns=['target_name','score'])
file_name = f'case study/{drug_name}.csv'
top_10_df.to_csv(file_name,index=False)






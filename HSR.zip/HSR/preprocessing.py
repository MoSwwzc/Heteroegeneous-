import pandas as pd
from pathlib import Path
import numpy as np

ROOT = Path(".")


def similarity_to_adjacency(similarity_df: pd.DataFrame, top_threshold: float = 0.05) -> pd.DataFrame:
    _ = similarity_df.values.flatten()
    threshold = np.sort(_)[int((1 - top_threshold) * len(_))]
    return similarity_df.where(similarity_df < threshold, 1).astype(int)


for d in ["dataset1"]:
    ld_adj = pd.read_csv(f"raw_data/{d}/adj/ld.csv", index_col=0)
    dd_sim = pd.read_csv(f"raw_data/{d}/sim/dd.csv", index_col=0)
    ll_sim = pd.read_csv(f"raw_data/{d}/sim/ll.csv", index_col=0)

    assert ll_sim.shape[0] == ld_adj.shape[0] and dd_sim.shape[0] == ld_adj.shape[1]

    ds_dir = ROOT / d / "adj"

    sim_dir = ds_dir / "sim"
    sim_dir.mkdir(parents=True, exist_ok=True)
    dd_sim.to_csv(sim_dir / "dd.csv")
    ll_sim.to_csv(sim_dir / "ll.csv")
    ld_adj.to_csv(sim_dir / "ld.csv")

    for t in [0.01, 0.02, 0.05, 0.10, 0.20]:
        adj_dir = ds_dir / f"{t * 100}%"
        adj_dir.mkdir(parents=True, exist_ok=True)

        dd_adj = similarity_to_adjacency(dd_sim, t)
        tt_adj = similarity_to_adjacency(ll_sim, t)

        dd_adj.to_csv(adj_dir / "dd.csv")
        tt_adj.to_csv(adj_dir / "ll.csv")
        ld_adj.to_csv(adj_dir / "ld.csv")

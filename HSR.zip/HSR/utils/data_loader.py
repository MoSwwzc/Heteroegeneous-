from sklearn.decomposition import PCA
import torch
import pandas as pd
from sklearn.model_selection import KFold
from easydict import EasyDict as edict
from pathlib import Path


def preparation(n_features, dataset_dir, top_thr, not_rand_feat=True, pca=False, device="cpu"):
    if isinstance(dataset_dir, str):
        dataset_dir = Path(dataset_dir)

    top_thr_per = "{:.1%}".format(top_thr) # for example, "5.0%"

    # ============ load dataset in Pandas ============
    dd_sim_df = pd.read_csv(dataset_dir /
                            "adj" / "sim" / "dd.csv", index_col=0)
    ll_sim_df = pd.read_csv(dataset_dir /
                            "adj" / "sim" / "ll.csv", index_col=0)

    dd_adj_df = pd.read_csv(dataset_dir /
                            "adj" / top_thr_per / "dd.csv", index_col=0)
    ll_adj_df = pd.read_csv(dataset_dir /
                            "adj" / top_thr_per / "ll.csv", index_col=0)
    ld_adj_df = pd.read_csv(dataset_dir /
                            "adj" / top_thr_per / "ld.csv", index_col=0)

    # ============ Pandas to Tensor ============
    # Similarity Matrix
    dd_sim = torch.from_numpy(dd_sim_df.values).to(device)
    ll_sim = torch.from_numpy(ll_sim_df.values).to(device)

    # Adjacency Matrix
    dd_adj = torch.from_numpy(dd_adj_df.values).to(device)
    ll_adj = torch.from_numpy(ll_adj_df.values).to(device)
    ld_adj = torch.from_numpy(ld_adj_df.values).to(device)

    # ============ Create features for nodes ============
    if not_rand_feat:
        node_features = {
            "drug": torch.cat([dd_sim, torch.zeros(dd_sim.shape[0], ll_sim.shape[0]).to(device)], dim=1).float(),
            "lncRNA": torch.cat([torch.zeros(ll_sim.shape[0], dd_sim.shape[0]).to(device), ll_sim], dim=1).float(),
        }
        if pca:
            # 按照给出的示例合并特征矩阵
            drug_features = torch.cat([dd_sim, torch.zeros(dd_sim.shape[0], ll_sim.shape[0]).to(device)], dim=1).float()
            lncRNA_features = torch.cat([torch.zeros(ll_sim.shape[0], dd_sim.shape[0]).to(device), ll_sim], dim=1).float()

            # 创建PCA对象，设置n_components为32
            feat_pca = PCA(n_components=n_features)

            # 使用numpy()将特征矩阵转换为NumPy数组
            drug_features_np = drug_features.cpu().numpy()
            lncRNA_features_np = lncRNA_features.cpu().numpy()

            # 对药物特征矩阵和靶点特征矩阵分别进行PCA降维
            feat_pca.fit(drug_features_np)
            feat_pca.fit(lncRNA_features_np)

            # 使用PCA对象将特征降维
            compressed_drug_features = feat_pca.transform(drug_features_np)
            compressed_lncRNA_features = feat_pca.transform(lncRNA_features_np)

            node_features = {
                "drug": torch.from_numpy(compressed_drug_features).to(device),
                "lncRNA": torch.from_numpy(compressed_lncRNA_features).to(device),
            }
            
    else:
        node_features = {
            "drug": torch.randn(dd_sim.shape[0], n_features).to(device),
            "lncRNA": torch.randn(ll_sim.shape[0], n_features).to(device),
        }

    return edict(dd_sim=dd_sim, ll_sim=ll_sim,
                 dd_adj=dd_adj, ll_adj=ll_adj, ld_adj=ld_adj,
                 node_features=node_features, dd_sim_df=dd_sim_df, ll_sim_df=ll_sim_df, ld_adj_df=ld_adj_df)


def train_test_split(dt_adj, kfold: int, train_ratio: float):
    # Number of 1 in DT adjacency matrix
    n_dti = int(torch.sum(dt_adj))


    # Generate random edge index
    rand_eids = torch.randperm(n_dti)
    
    run_once = kfold == 0
    if run_once:
        test_size = int(n_dti * (1 - train_ratio))
        ready_to_run = [
            (rand_eids[test_size:],
             rand_eids[:test_size],)
        ]
    else:
        kf = KFold(n_splits=kfold)
        kf.get_n_splits(rand_eids)
        ready_to_run = kf.split(rand_eids)
    return ready_to_run

def train_valid_test_split(ld_adj, kfold: int, train_ratio: float, valid_ratio: float):
    """
    return [(train_index, valid_index, test_index), ...]
    # +-----------------+-----------------+-----------------+-----------------+
    # |    kfold > 1    |   train_ratio   |    val_ratio    |    test_ratio   |
    # | --------------- | --------------- | --------------- | --------------- |
    # |      True       |   a  * (1-1/K)  | (1-a) * (1-1/K) |       1/K       |  ignore val_ratio
    # |      False      |        a        |        b        |    1 - a - b    |
    # +-----------------+-----------------+-----------------+-----------------+
    """
    # Number of 1 in DT adjacency matrix
    n_dti = int(torch.sum(ld_adj))

    # 选取一半的关系对数量
    half_n_dti = n_dti // 1

    # 生成随机排列的索引
    rand_eids = torch.randperm(n_dti)

    # 只选取前一半的索引
    half_rand_eids = rand_eids[:half_n_dti]



    # # Generate random edge index
    # rand_eids = torch.randperm(n_dti)

    
    run_once = kfold == 0 or kfold == 1
    if run_once:
        # 计算训练集和验证集的大小
        train_size = int(half_n_dti * train_ratio)
        valid_size = int(half_n_dti * valid_ratio)
        # train_size = int(n_dti * train_ratio)
        # valid_size = int(n_dti * valid_ratio)
        
        ready_to_run = [
            (rand_eids[:train_size], rand_eids[train_size:train_size+valid_size], rand_eids[train_size+valid_size:])
        ]
    else:
        kf = KFold(n_splits=kfold)
        ready_to_run = []
        for train_valid_set, test_set in kf.split(rand_eids):
            train_size = int(len(train_valid_set) * train_ratio)
            
            ready_to_run.append(
                (rand_eids[train_valid_set[:train_size]], rand_eids[train_valid_set[train_size:]], rand_eids[test_set])
            )

    return ready_to_run
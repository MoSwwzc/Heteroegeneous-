import numpy as np
import torch
from typing import Union, List
import dgl

TOP_LIST = [0.01, 0.02, 0.05, 0.1]

def graph_to_adj(g, etype):
    return g.adjacency_matrix(etype=etype).to_dense().to(g.device)

def construct_graph_bak(dd_adj: torch.Tensor,
                    ll_adj: torch.Tensor,
                    ld_adj: torch.Tensor,
                    train_edge_index: Union[torch.Tensor, np.ndarray, List],
                    test_edge_index: Union[torch.Tensor, np.ndarray, List],
                    device="cpu"):

    # u: drug,  v: lncRNA
    u, v = torch.where(ld_adj)

    # choose u,v by index
    test_u, test_v = u[test_edge_index], v[test_edge_index]
    train_u, train_v = u[train_edge_index], v[train_edge_index]

    # ld adj split to train and test
    train_ld_adj = torch.zeros_like(ld_adj)
    train_ld_adj[train_u, train_v] = 1
    test_ld_adj = torch.zeros_like(ld_adj)
    test_ld_adj[test_u, test_v] = 1

    dd_edges = torch.where(dd_adj)
    ll_edges = torch.where(ll_adj)

    g = dgl.heterograph({
        ('drug', 'dd', 'drug'): dd_edges,
        ('lncRNA', 'll', 'lncRNA'): ll_edges,
        ('lncRNA', 'ld', 'drug'): (u, v),
        ('drug', 'dl', 'lncRNA'): (v, u),
    }, num_nodes_dict={"drug": ld_adj.shape[1], "lncRNA": ld_adj.shape[0]}).to(device)

    train_g = dgl.heterograph({
        ('drug', 'dd', 'drug'): dd_edges,
        ('lncRNA', 'll', 'lncRNA'): ll_edges,
        ('lncRNA', 'ld', 'drug'): (train_u, train_v),
        ('drug', 'dl', 'lncRNA'): (train_v, train_u),
    }, num_nodes_dict={"drug": train_ld_adj.shape[1], "lncRNA": train_ld_adj.shape[0]}).to(device)

    test_g = dgl.heterograph({
        ('drug', 'dd', 'drug'): dd_edges,
        ('lncRNA', 'll', 'lncRNA'): ll_edges,
        ('lncRNA', 'ld', 'drug'): (test_u, test_v),
        ('drug', 'dl', 'lncRNA'): (test_v, test_u),
    }, num_nodes_dict={"drug": test_ld_adj.shape[1], "lncRNA": test_ld_adj.shape[0]}).to(device)

    return train_g, test_g, g


def construct_graph(dd_adj: torch.Tensor,
                    ll_adj: torch.Tensor,
                    ld_adj: torch.Tensor,
                    train_edge_index: Union[torch.Tensor, np.ndarray, List],
                    valid_edge_index: Union[torch.Tensor, np.ndarray, List],
                    test_edge_index: Union[torch.Tensor, np.ndarray, List],
                    device="cpu"):

    # u: drug,  v: lncRNA
    u, v = torch.where(ld_adj)

    # choose u,v by index
    test_u, test_v = u[test_edge_index], v[test_edge_index]
    train_u, train_v = u[train_edge_index], v[train_edge_index]
    valid_u, valid_v = u[valid_edge_index], v[valid_edge_index]

    # DT adj split to train and test
    train_ld_adj = torch.zeros_like(ld_adj)
    train_ld_adj[train_u, train_v] = 1
    test_ld_adj = torch.zeros_like(ld_adj)
    test_ld_adj[test_u, test_v] = 1
    valid_ld_adj = torch.zeros_like(ld_adj)
    valid_ld_adj[valid_u, valid_v] = 1

    dd_edges = torch.where(dd_adj)
    ll_edges = torch.where(ll_adj)

    g = dgl.heterograph({
        ('drug', 'dd', 'drug'): dd_edges,
        ('lncRNA', 'll', 'lncRNA'): ll_edges,
        ('lncRNA', 'ld', 'drug'): (u, v),
        ('drug', 'dl', 'lncRNA'): (v, u),
    }, num_nodes_dict={"drug": ld_adj.shape[1], "lncRNA": ld_adj.shape[0]}).to(device)

    train_g = dgl.heterograph({
        ('drug', 'dd', 'drug'): dd_edges,
        ('lncRNA', 'll', 'lncRNA'): ll_edges,
        ('lncRNA', 'ld', 'drug'): (train_u, train_v),
        ('drug', 'dl', 'lncRNA'): (train_v, train_u),
    }, num_nodes_dict={"drug": train_ld_adj.shape[1], "lncRNA": train_ld_adj.shape[0]}).to(device)

    valid_g = dgl.heterograph({
        ('drug', 'dd', 'drug'): dd_edges,
        ('lncRNA', 'll', 'lncRNA'): ll_edges,
        ('lncRNA', 'ld', 'drug'): (valid_u, valid_v),
        ('drug', 'dl', 'lncRNA'): (valid_v, valid_u),
    }, num_nodes_dict={"drug": valid_ld_adj.shape[1], "lncRNA": valid_ld_adj.shape[0]}).to(device)


    test_g = dgl.heterograph({
        ('drug', 'dd', 'drug'): dd_edges,
        ('lncRNA', 'll', 'lncRNA'): ll_edges,
        ('lncRNA', 'ld', 'drug'): (test_u, test_v),
        ('drug', 'dl', 'lncRNA'): (test_v, test_u),
    }, num_nodes_dict={"drug": test_ld_adj.shape[1], "lncRNA": test_ld_adj.shape[0]}).to(device)

    return train_g, valid_g, test_g, g



def construct_multi_graphs(dd_adj: torch.Tensor,
                           ll_adj: torch.Tensor,
                           ld_adj: torch.Tensor,
                           train_edge_index: Union[torch.Tensor, np.ndarray, List],
                           test_edge_index: Union[torch.Tensor, np.ndarray, List],
                           dd_sim: torch.Tensor,
                           ll_sim: torch.Tensor,
                           tops: List = TOP_LIST,
                           device="cpu"):

    train_g, test_g, g = construct_graph(dd_adj=dd_adj, ll_adj=ll_adj, ld_adj=ld_adj,
                                         train_edge_index=train_edge_index, test_edge_index=test_edge_index, 
                                         device=device)

    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ tops @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    train_gs = []
    for top in tops:
        _g = dgl.heterograph({
            ('drug', 'dd', 'drug'): torch.where(dd_sim > torch.quantile(dd_sim.ravel(), q=1 - top)),
            ('lncRNA', 'll', 'lncRNA'): torch.where(ll_sim > torch.quantile(ll_sim.ravel(), q=1 - top)),
            ('lncRNA', 'ld', 'drug'): train_g.edges(etype="ld"),
            ('drug', 'dl', 'lncRNA'): train_g.edges(etype="dl"),
        }, num_nodes_dict={"drug": dd_sim.shape[0], "lncRNA": ll_sim.shape[0]}).to(device)
        train_gs.append(_g)

    test_gs = []
    for top in tops:
        _g = dgl.heterograph({
            ('drug', 'dd', 'drug'): torch.where(dd_sim > torch.quantile(dd_sim.ravel(), q=1 - top)),
            ('lncRNA', 'll', 'lncRNA'): torch.where(ll_sim > torch.quantile(ll_sim.ravel(), q=1 - top)),
            ('lncRNA', 'ld', 'drug'): test_g.edges(etype="ld"),
            ('drug', 'dl', 'lncRNA'): test_g.edges(etype="dl"),
        }, num_nodes_dict={"drug": dd_sim.shape[0], "lncRNA": ll_sim.shape[0]}).to(device)
        test_gs.append(_g)
    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

    return train_gs, test_gs, g
